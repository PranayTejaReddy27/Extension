const handleSubmit = async (event) => {
  event.preventDefault(); // Prevent the default form submission behavior

  // Fetch form data
  const title = document.getElementById('title').value;
  const favicon = document.getElementById('favicon').value;
  const category = document.getElementById('sortingOptions').value;
  const tags = document.getElementById('tags').value;
  const url = document.getElementById('url').value;


  const xhr = new XMLHttpRequest();


  xhr.open('PUT', '/submit-form');
  xhr.setRequestHeader('Content-Type', 'application/json');


  const data = JSON.stringify({title,favicon,category, url, tags });


  xhr.send(data);


  xhr.onload = function() {
      if (xhr.status === 200) {
          console.log('Form data sent successfully');
          document.getElementById('title').value = '';
          document.getElementById('url').value = '';
          document.getElementById('tags').value = '';
          document.getElementById('favicon').value = '';
          document.getElementById('sortingOptions').value = '';
      } else {
          console.error('Failed to send form data');
      }
  };

  xhr.onerror = function() {
      console.error('Error sending form data');
  };
};


document.getElementById('submitBtn').addEventListener('click', handleSubmit);
